import { useEffect } from "react";
import { useMario } from "@/lib/stores/useMario";
import { useGame } from "@/lib/stores/useGame";
import { useAudio } from "@/lib/stores/useAudio";

export function GameUI() {
  const { score, lives, coins } = useMario();
  const { phase, start, restart } = useGame();
  const { isMuted, toggleMute, setBackgroundMusic, setHitSound, setSuccessSound } = useAudio();

  useEffect(() => {
    const bgMusic = new Audio("/sounds/background.mp3");
    bgMusic.loop = true;
    bgMusic.volume = 0.3;
    setBackgroundMusic(bgMusic);

    const hit = new Audio("/sounds/hit.mp3");
    setHitSound(hit);

    const success = new Audio("/sounds/success.mp3");
    setSuccessSound(success);
  }, [setBackgroundMusic, setHitSound, setSuccessSound]);

  useEffect(() => {
    const bgMusic = useAudio.getState().backgroundMusic;
    if (bgMusic && phase === "playing" && !isMuted) {
      bgMusic.play().catch(console.log);
    } else if (bgMusic) {
      bgMusic.pause();
    }
  }, [phase, isMuted]);

  const handleStart = () => {
    console.log("Starting game...");
    start();
  };

  const handleRestart = () => {
    console.log("Restarting game...");
    useMario.getState().reset();
    restart();
  };

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      pointerEvents: 'none',
      fontFamily: 'Inter, sans-serif',
    }}>
      <div style={{
        position: 'absolute',
        top: '20px',
        left: '20px',
        padding: '15px 25px',
        background: 'rgba(0, 0, 0, 0.8)',
        color: 'white',
        borderRadius: '10px',
        fontSize: '18px',
        fontWeight: 'bold',
      }}>
        <div>Score: {score}</div>
        <div>Coins: {coins}</div>
        <div>Lives: {'❤️'.repeat(lives)}</div>
      </div>

      <button
        onClick={toggleMute}
        style={{
          position: 'absolute',
          top: '20px',
          right: '20px',
          padding: '10px 20px',
          background: 'rgba(0, 0, 0, 0.8)',
          color: 'white',
          border: 'none',
          borderRadius: '8px',
          cursor: 'pointer',
          fontSize: '16px',
          pointerEvents: 'auto',
        }}
      >
        {isMuted ? '🔇 Unmute' : '🔊 Mute'}
      </button>

      {phase === "ready" && (
        <div style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          textAlign: 'center',
          background: 'rgba(0, 0, 0, 0.9)',
          padding: '40px 60px',
          borderRadius: '20px',
          color: 'white',
        }}>
          <h1 style={{ fontSize: '48px', margin: '0 0 20px 0', color: '#FFD700' }}>
            Super Mario Clone
          </h1>
          <p style={{ fontSize: '20px', marginBottom: '30px' }}>
            Use Arrow Keys or WASD to move<br />
            Press SPACE to jump
          </p>
          <button
            onClick={handleStart}
            style={{
              padding: '15px 40px',
              fontSize: '24px',
              fontWeight: 'bold',
              background: '#4CAF50',
              color: 'white',
              border: 'none',
              borderRadius: '10px',
              cursor: 'pointer',
              pointerEvents: 'auto',
            }}
          >
            Start Game
          </button>
        </div>
      )}

      {phase === "ended" && (
        <div style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          textAlign: 'center',
          background: 'rgba(0, 0, 0, 0.9)',
          padding: '40px 60px',
          borderRadius: '20px',
          color: 'white',
        }}>
          <h1 style={{ fontSize: '48px', margin: '0 0 20px 0', color: '#FF4444' }}>
            Game Over!
          </h1>
          <p style={{ fontSize: '28px', marginBottom: '10px' }}>
            Final Score: {score}
          </p>
          <p style={{ fontSize: '24px', marginBottom: '30px' }}>
            Coins Collected: {coins}
          </p>
          <button
            onClick={handleRestart}
            style={{
              padding: '15px 40px',
              fontSize: '24px',
              fontWeight: 'bold',
              background: '#4CAF50',
              color: 'white',
              border: 'none',
              borderRadius: '10px',
              cursor: 'pointer',
              pointerEvents: 'auto',
            }}
          >
            Restart
          </button>
        </div>
      )}

      {phase === "completed" && (
        <div style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          textAlign: 'center',
          background: 'rgba(0, 0, 0, 0.9)',
          padding: '40px 60px',
          borderRadius: '20px',
          color: 'white',
        }}>
          <h1 style={{ fontSize: '60px', margin: '0 0 20px 0', color: '#FFD700' }}>
            Level Done
          </h1>
          <p style={{ fontSize: '28px', marginBottom: '10px' }}>
            Final Score: {score}
          </p>
          <p style={{ fontSize: '24px', marginBottom: '30px' }}>
            All {coins} Coins Collected!
          </p>
          <button
            onClick={handleRestart}
            style={{
              padding: '15px 40px',
              fontSize: '24px',
              fontWeight: 'bold',
              background: '#4CAF50',
              color: 'white',
              border: 'none',
              borderRadius: '10px',
              cursor: 'pointer',
              pointerEvents: 'auto',
            }}
          >
            Play Again
          </button>
        </div>
      )}
    </div>
  );
}
