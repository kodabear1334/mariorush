import { useRef, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import { useMario } from "@/lib/stores/useMario";
import { useGame } from "@/lib/stores/useGame";
import { useAudio } from "@/lib/stores/useAudio";
import * as THREE from "three";

interface Coin {
  id: number;
  position: THREE.Vector3;
  collected: boolean;
  rotation: number;
}

const COIN_POSITIONS = [
  [5, 2, 0],
  [7, 2, 0],
  [9, 4, 0],
  [16, 6, 0],
  [23, 5, 0],
  [31, 7, 0],
  [33, 7, 0],
  [35, 7, 0],
  [41, 4, 0],
];

export function Coins() {
  const coinsRef = useRef<Coin[]>([]);
  const { position: marioPos, addCoin, coins } = useMario();
  const { phase, complete } = useGame();
  const { playSuccess } = useAudio();

  const initializeCoins = () => {
    coinsRef.current = COIN_POSITIONS.map((pos, index) => ({
      id: index,
      position: new THREE.Vector3(pos[0], pos[1], pos[2]),
      collected: false,
      rotation: 0,
    }));
  };

  useEffect(() => {
    initializeCoins();
  }, []);

  useEffect(() => {
    if (phase === "ready") {
      initializeCoins();
      console.log("Coins reset for new game");
    }
  }, [phase]);

  useEffect(() => {
    if (phase === "playing" && coins === COIN_POSITIONS.length) {
      console.log("All coins collected! Level complete!");
      complete();
    }
  }, [coins, phase, complete]);

  useFrame((state, delta) => {
    if (phase !== "playing") return;

    const COLLECTION_DISTANCE = 1.0;

    coinsRef.current.forEach((coin) => {
      if (coin.collected) return;

      coin.rotation += delta * 3;

      const dx = marioPos[0] - coin.position.x;
      const dy = marioPos[1] - coin.position.y;
      const distance = Math.sqrt(dx * dx + dy * dy);

      if (distance < COLLECTION_DISTANCE) {
        console.log(`Coin ${coin.id} collected!`);
        coin.collected = true;
        addCoin();
        playSuccess();
      }
    });
  });

  return (
    <group>
      {coinsRef.current.map((coin) =>
        !coin.collected ? (
          <group key={coin.id} position={coin.position} rotation={[0, coin.rotation, 0]}>
            {/* Main gold coin */}
            <mesh>
              <cylinderGeometry args={[0.35, 0.35, 0.12, 20]} />
              <meshStandardMaterial 
                color="#FFD700" 
                metalness={0.9} 
                roughness={0.1}
                emissive="#FFA500"
                emissiveIntensity={0.2}
              />
            </mesh>
            
            {/* Inner circle detail */}
            <mesh position={[0, 0.061, 0]}>
              <cylinderGeometry args={[0.25, 0.25, 0.01, 20]} />
              <meshStandardMaterial 
                color="#FFED4E" 
                metalness={1} 
                roughness={0.05}
              />
            </mesh>
            
            {/* Glow effect */}
            <pointLight 
              color="#FFD700" 
              intensity={0.5} 
              distance={2} 
            />
          </group>
        ) : null
      )}
    </group>
  );
}
