import { useRef, useMemo, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import { useMario } from "@/lib/stores/useMario";
import { useGame } from "@/lib/stores/useGame";
import { useAudio } from "@/lib/stores/useAudio";
import * as THREE from "three";

interface Enemy {
  id: number;
  position: THREE.Vector3;
  direction: number;
  minX: number;
  maxX: number;
  alive: boolean;
}

const ENEMY_SPAWN_DATA = [
  { id: 1, startX: 10, minX: 8, maxX: 14 },
  { id: 2, startX: 20, minX: 18, maxX: 24 },
  { id: 3, startX: 28, minX: 26, maxX: 32 },
  { id: 4, startX: 35, minX: 33, maxX: 38 },
];

export function Enemies() {
  const enemiesRef = useRef<Enemy[]>([]);
  const { position: marioPos, loseLife, addScore } = useMario();
  const { phase, end } = useGame();
  const { playHit } = useAudio();

  const initializeEnemies = () => {
    enemiesRef.current = ENEMY_SPAWN_DATA.map((data) => ({
      id: data.id,
      position: new THREE.Vector3(data.startX, 1, 0),
      direction: 1,
      minX: data.minX,
      maxX: data.maxX,
      alive: true,
    }));
  };

  useEffect(() => {
    initializeEnemies();
  }, []);

  useEffect(() => {
    if (phase === "ready") {
      initializeEnemies();
      console.log("Enemies reset for new game");
    }
  }, [phase]);

  useFrame((state, delta) => {
    if (phase !== "playing") return;

    const ENEMY_SPEED = 2;
    const COLLISION_DISTANCE = 1.2;
    const marioState = useMario.getState();
    const isInvincible = marioState.invincibilityTime > 0;

    enemiesRef.current.forEach((enemy) => {
      if (!enemy.alive) return;

      enemy.position.x += enemy.direction * ENEMY_SPEED * delta;

      if (enemy.position.x >= enemy.maxX) {
        enemy.direction = -1;
      } else if (enemy.position.x <= enemy.minX) {
        enemy.direction = 1;
      }

      const dx = marioPos[0] - enemy.position.x;
      const dy = marioPos[1] - enemy.position.y;
      const distance = Math.sqrt(dx * dx + dy * dy);

      if (distance < COLLISION_DISTANCE) {
        if (marioPos[1] > enemy.position.y + 0.5) {
          console.log(`Enemy ${enemy.id} defeated!`);
          enemy.alive = false;
          addScore(200);
          playHit();
        } else if (!isInvincible) {
          console.log("Mario hit by enemy!");
          loseLife();
          playHit();
          
          if (useMario.getState().lives <= 0) {
            end();
          }
        }
      }
    });
  });

  return (
    <group>
      {enemiesRef.current.map((enemy) =>
        enemy.alive ? (
          <group key={enemy.id} position={enemy.position}>
            {/* Goomba body (brown mushroom look) */}
            <mesh position={[0, 0, 0]} castShadow>
              <boxGeometry args={[0.7, 0.6, 0.7]} />
              <meshStandardMaterial color="#8B4513" />
            </mesh>
            
            {/* Goomba head/cap */}
            <mesh position={[0, 0.45, 0]} castShadow>
              <boxGeometry args={[0.85, 0.3, 0.85]} />
              <meshStandardMaterial color="#654321" />
            </mesh>
            
            {/* Eyes */}
            <mesh position={[-0.15, 0.1, 0.36]}>
              <boxGeometry args={[0.12, 0.12, 0.05]} />
              <meshStandardMaterial color="#000000" />
            </mesh>
            <mesh position={[0.15, 0.1, 0.36]}>
              <boxGeometry args={[0.12, 0.12, 0.05]} />
              <meshStandardMaterial color="#000000" />
            </mesh>
            
            {/* Angry eyebrows */}
            <mesh position={[0, 0.22, 0.36]}>
              <boxGeometry args={[0.5, 0.05, 0.05]} />
              <meshStandardMaterial color="#000000" />
            </mesh>
          </group>
        ) : null
      )}
    </group>
  );
}
