import { useRef, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import { useKeyboardControls } from "@react-three/drei";
import { useMario } from "@/lib/stores/useMario";
import { useGame } from "@/lib/stores/useGame";
import * as THREE from "three";

enum Controls {
  left = 'left',
  right = 'right',
  jump = 'jump',
}

const platforms = [
  { position: [0, 0, 0], size: [100, 1, 10] },
  { position: [8, 3, 0], size: [4, 0.5, 4] },
  { position: [15, 5, 0], size: [3, 0.5, 4] },
  { position: [22, 4, 0], size: [4, 0.5, 4] },
  { position: [30, 6, 0], size: [5, 0.5, 4] },
  { position: [40, 3, 0], size: [3, 0.5, 4] },
];

export function Mario() {
  const meshRef = useRef<THREE.Mesh>(null);
  const {
    position,
    velocity,
    isGrounded,
    isJumping,
    isDead,
    invincibilityTime,
    setPosition,
    setVelocity,
    setGrounded,
    setJumping,
    setInvincibility,
    updateInvincibility,
    loseLife,
  } = useMario();
  
  const { phase } = useGame();
  const [, getKeys] = useKeyboardControls<Controls>();

  useEffect(() => {
    console.log("Mario initialized at position:", position);
  }, []);

  useFrame((state, delta) => {
    if (phase !== "playing" || isDead) return;

    updateInvincibility(delta);

    const keys = getKeys();
    let [vx, vy, vz] = velocity;
    let [px, py, pz] = position;

    const MOVE_SPEED = 8;
    const JUMP_FORCE = 12;
    const GRAVITY = -30;
    const MAX_FALL_SPEED = -20;
    const MARIO_HEIGHT = 1.2;
    const MARIO_WIDTH = 0.8;

    if (keys.left) {
      vx = -MOVE_SPEED;
    } else if (keys.right) {
      vx = MOVE_SPEED;
    } else {
      vx = 0;
    }

    if (keys.jump && isGrounded && !isJumping) {
      vy = JUMP_FORCE;
      setGrounded(false);
      setJumping(true);
      console.log("Jump!");
    }

    if (!isGrounded) {
      vy += GRAVITY * delta;
      vy = Math.max(vy, MAX_FALL_SPEED);
    }

    px += vx * delta;
    py += vy * delta;

    let onPlatform = false;

    for (const platform of platforms) {
      const [platX, platY, platZ] = platform.position;
      const [platW, platH, platD] = platform.size;

      const platLeft = platX - platW / 2;
      const platRight = platX + platW / 2;
      const platTop = platY + platH / 2;
      const platBottom = platY - platH / 2;

      const marioLeft = px - MARIO_WIDTH / 2;
      const marioRight = px + MARIO_WIDTH / 2;
      const marioBottom = py - MARIO_HEIGHT / 2;

      const isAbovePlatform = marioLeft < platRight && marioRight > platLeft;
      
      if (isAbovePlatform && vy <= 0) {
        const distanceToTop = marioBottom - platTop;
        
        if (distanceToTop < 0.5 && distanceToTop > -0.5) {
          py = platTop + MARIO_HEIGHT / 2;
          vy = 0;
          onPlatform = true;
          setGrounded(true);
          setJumping(false);
          break;
        }
      }
    }

    if (!onPlatform && py <= MARIO_HEIGHT / 2) {
      py = MARIO_HEIGHT / 2;
      vy = 0;
      setGrounded(true);
      setJumping(false);
    } else if (!onPlatform && py > MARIO_HEIGHT / 2) {
      setGrounded(false);
    }

    if (py < -5) {
      console.log("Mario fell off the world!");
      loseLife();
      setInvincibility(2);
      px = 0;
      py = 2;
      pz = 0;
      vx = 0;
      vy = 0;
      vz = 0;
    }

    setPosition([px, py, pz]);
    setVelocity([vx, vy, vz]);

    if (meshRef.current) {
      meshRef.current.position.set(px, py, pz);
    }

    state.camera.position.x = THREE.MathUtils.lerp(
      state.camera.position.x,
      px,
      0.1
    );
  });

  const isInvincible = invincibilityTime > 0;
  const opacity = isInvincible && Math.floor(invincibilityTime * 10) % 2 === 0 ? 0.5 : 1;

  return (
    <group ref={meshRef as any} position={position}>
      {/* Blue overalls (legs) */}
      <mesh position={[0, -0.35, 0]} castShadow>
        <boxGeometry args={[0.6, 0.5, 0.6]} />
        <meshStandardMaterial color="#0066ff" transparent opacity={opacity} />
      </mesh>
      
      {/* Red shirt (body) */}
      <mesh position={[0, 0.1, 0]} castShadow>
        <boxGeometry args={[0.7, 0.5, 0.65]} />
        <meshStandardMaterial color="#ff0000" transparent opacity={opacity} />
      </mesh>
      
      {/* Skin tone (head) */}
      <mesh position={[0, 0.5, 0]} castShadow>
        <boxGeometry args={[0.5, 0.4, 0.5]} />
        <meshStandardMaterial color="#ffcc99" transparent opacity={opacity} />
      </mesh>
      
      {/* Red cap */}
      <mesh position={[0, 0.75, 0]} castShadow>
        <boxGeometry args={[0.55, 0.15, 0.55]} />
        <meshStandardMaterial color="#cc0000" transparent opacity={opacity} />
      </mesh>
      
      {/* Mustache */}
      <mesh position={[0, 0.45, 0.26]} castShadow>
        <boxGeometry args={[0.4, 0.08, 0.05]} />
        <meshStandardMaterial color="#222222" transparent opacity={opacity} />
      </mesh>
    </group>
  );
}
