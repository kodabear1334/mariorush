import { useMemo } from "react";
import * as THREE from "three";

function BrickBlock({ position }: { position: [number, number, number] }) {
  return (
    <mesh position={position} receiveShadow castShadow>
      <boxGeometry args={[1, 1, 1]} />
      <meshStandardMaterial color="#D2691E">
        <primitive 
          attach="map" 
          object={useMemo(() => {
            const canvas = document.createElement('canvas');
            canvas.width = 64;
            canvas.height = 64;
            const ctx = canvas.getContext('2d')!;
            
            ctx.fillStyle = '#C85A17';
            ctx.fillRect(0, 0, 64, 64);
            
            ctx.strokeStyle = '#A0522D';
            ctx.lineWidth = 2;
            ctx.strokeRect(2, 2, 60, 60);
            
            ctx.strokeStyle = '#8B4513';
            ctx.lineWidth = 1;
            ctx.strokeRect(8, 8, 48, 48);
            
            const texture = new THREE.CanvasTexture(canvas);
            texture.wrapS = THREE.RepeatWrapping;
            texture.wrapT = THREE.RepeatWrapping;
            return texture;
          }, [])}
        />
      </meshStandardMaterial>
    </mesh>
  );
}

function QuestionBlock({ position }: { position: [number, number, number] }) {
  return (
    <mesh position={position} castShadow>
      <boxGeometry args={[1, 1, 1]} />
      <meshStandardMaterial color="#FFB900">
        <primitive 
          attach="map" 
          object={useMemo(() => {
            const canvas = document.createElement('canvas');
            canvas.width = 64;
            canvas.height = 64;
            const ctx = canvas.getContext('2d')!;
            
            ctx.fillStyle = '#FFB900';
            ctx.fillRect(0, 0, 64, 64);
            
            ctx.strokeStyle = '#CC9200';
            ctx.lineWidth = 2;
            ctx.strokeRect(2, 2, 60, 60);
            
            ctx.fillStyle = '#000000';
            ctx.font = 'bold 48px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('?', 32, 32);
            
            const texture = new THREE.CanvasTexture(canvas);
            return texture;
          }, [])}
        />
      </meshStandardMaterial>
    </mesh>
  );
}

function Cloud({ position }: { position: [number, number, number] }) {
  return (
    <group position={position}>
      <mesh position={[0, 0, -8]}>
        <boxGeometry args={[2, 1, 0.5]} />
        <meshStandardMaterial color="#FFFFFF" />
      </mesh>
      <mesh position={[-1, 0.3, -8]}>
        <boxGeometry args={[1.2, 1.2, 0.5]} />
        <meshStandardMaterial color="#FFFFFF" />
      </mesh>
      <mesh position={[1, 0.3, -8]}>
        <boxGeometry args={[1.2, 1.2, 0.5]} />
        <meshStandardMaterial color="#FFFFFF" />
      </mesh>
      <mesh position={[0, 0.5, -8]}>
        <boxGeometry args={[1.5, 0.8, 0.5]} />
        <meshStandardMaterial color="#FFFFFF" />
      </mesh>
    </group>
  );
}

function Hill({ position, size = 1 }: { position: [number, number, number]; size?: number }) {
  return (
    <group position={position}>
      <mesh position={[0, 0, -7]}>
        <boxGeometry args={[3 * size, 1.5 * size, 0.5]} />
        <meshStandardMaterial color="#7BC850" />
      </mesh>
      <mesh position={[0, 0.8 * size, -7]}>
        <boxGeometry args={[2 * size, 1 * size, 0.5]} />
        <meshStandardMaterial color="#7BC850" />
      </mesh>
      <mesh position={[0, 1.3 * size, -7]}>
        <boxGeometry args={[1 * size, 0.6 * size, 0.5]} />
        <meshStandardMaterial color="#7BC850" />
      </mesh>
    </group>
  );
}

export function Level() {
  const groundBricks = useMemo(() => {
    const bricks = [];
    for (let x = -10; x < 60; x += 1) {
      bricks.push([x, 0, 0] as [number, number, number]);
    }
    return bricks;
  }, []);

  const floatingPlatforms = [
    { x: 8, y: 3, count: 4 },
    { x: 15, y: 5, count: 3 },
    { x: 22, y: 4, count: 4 },
    { x: 30, y: 6, count: 5 },
    { x: 40, y: 3, count: 3 },
  ];

  const questionBlocks = [
    [10, 5, 0] as [number, number, number],
    [17, 7, 0] as [number, number, number],
    [24, 6, 0] as [number, number, number],
    [32, 8, 0] as [number, number, number],
  ];

  const pipes = [
    { position: [12, 1.5, 0] as [number, number, number], height: 2 },
    { position: [25, 2, 0] as [number, number, number], height: 3 },
  ];

  const clouds = [
    [5, 9, 0] as [number, number, number],
    [18, 10, 0] as [number, number, number],
    [28, 9, 0] as [number, number, number],
    [40, 10, 0] as [number, number, number],
  ];

  const hills = [
    { position: [3, 0.5, 0] as [number, number, number], size: 1 },
    { position: [20, 0.5, 0] as [number, number, number], size: 1.2 },
    { position: [35, 0.5, 0] as [number, number, number], size: 0.9 },
  ];

  return (
    <group>
      {/* Ground bricks */}
      {groundBricks.map((pos, index) => (
        <BrickBlock key={`ground-${index}`} position={pos} />
      ))}

      {/* Floating brick platforms */}
      {floatingPlatforms.map((platform, pIndex) => {
        const bricks = [];
        for (let i = 0; i < platform.count; i++) {
          bricks.push(
            <BrickBlock 
              key={`platform-${pIndex}-${i}`} 
              position={[platform.x + i, platform.y, 0]} 
            />
          );
        }
        return bricks;
      })}

      {/* Question blocks */}
      {questionBlocks.map((pos, index) => (
        <QuestionBlock key={`question-${index}`} position={pos} />
      ))}

      {/* Pipes */}
      {pipes.map((pipe, index) => (
        <group key={`pipe-${index}`} position={pipe.position}>
          {/* Pipe body */}
          <mesh position={[0, pipe.height / 2, 0]} castShadow>
            <boxGeometry args={[1.8, pipe.height, 1.8]} />
            <meshStandardMaterial color="#4CAF50" />
          </mesh>
          {/* Pipe rim/top */}
          <mesh position={[0, pipe.height, 0]} castShadow>
            <boxGeometry args={[2.2, 0.4, 2.2]} />
            <meshStandardMaterial color="#4CAF50" />
          </mesh>
          {/* Inner shadow */}
          <mesh position={[0, pipe.height + 0.21, 0]}>
            <boxGeometry args={[1.6, 0.02, 1.6]} />
            <meshStandardMaterial color="#2E7D32" />
          </mesh>
        </group>
      ))}

      {/* Background clouds */}
      {clouds.map((pos, index) => (
        <Cloud key={`cloud-${index}`} position={pos} />
      ))}

      {/* Background hills */}
      {hills.map((hill, index) => (
        <Hill key={`hill-${index}`} position={hill.position} size={hill.size} />
      ))}
    </group>
  );
}
