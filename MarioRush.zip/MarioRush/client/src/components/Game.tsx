import { Canvas } from "@react-three/fiber";
import { Suspense } from "react";
import { Mario } from "./Mario";
import { Level } from "./Level";
import { Enemies } from "./Enemies";
import { Coins } from "./Coins";
import { GameUI } from "./GameUI";
import * as THREE from "three";

export function Game() {
  return (
    <>
      <Canvas
        camera={{
          position: [0, 5, 15],
          fov: 50,
          near: 0.1,
          far: 1000,
        }}
        gl={{
          antialias: true,
        }}
        shadows
      >
        <color attach="background" args={["#5c94fc"]} />
        
        <ambientLight intensity={0.8} />
        <directionalLight
          position={[10, 20, 10]}
          intensity={0.5}
          castShadow
          shadow-mapSize-width={2048}
          shadow-mapSize-height={2048}
          shadow-camera-far={50}
          shadow-camera-left={-20}
          shadow-camera-right={20}
          shadow-camera-top={20}
          shadow-camera-bottom={-20}
        />
        
        <Suspense fallback={null}>
          <Level />
          <Mario />
          <Enemies />
          <Coins />
        </Suspense>
      </Canvas>
      
      <GameUI />
    </>
  );
}
