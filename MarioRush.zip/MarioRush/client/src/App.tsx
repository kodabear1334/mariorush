import { KeyboardControls } from "@react-three/drei";
import { useEffect, useState } from "react";
import { Game } from "./components/Game";
import "@fontsource/inter";

enum Controls {
  left = 'left',
  right = 'right',
  jump = 'jump',
}

const keyMap = [
  { name: Controls.left, keys: ['ArrowLeft', 'KeyA'] },
  { name: Controls.right, keys: ['ArrowRight', 'KeyD'] },
  { name: Controls.jump, keys: ['Space', 'ArrowUp', 'KeyW'] },
];

function App() {
  const [showCanvas, setShowCanvas] = useState(false);

  useEffect(() => {
    setShowCanvas(true);
  }, []);

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', overflow: 'hidden' }}>
      {showCanvas && (
        <KeyboardControls map={keyMap}>
          <Game />
        </KeyboardControls>
      )}
    </div>
  );
}

export default App;
