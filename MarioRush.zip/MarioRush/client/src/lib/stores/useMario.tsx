import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

interface MarioState {
  score: number;
  lives: number;
  coins: number;
  position: [number, number, number];
  velocity: [number, number, number];
  isGrounded: boolean;
  isJumping: boolean;
  isDead: boolean;
  invincibilityTime: number;
  
  addScore: (points: number) => void;
  addCoin: () => void;
  loseLife: () => void;
  setPosition: (position: [number, number, number]) => void;
  setVelocity: (velocity: [number, number, number]) => void;
  setGrounded: (grounded: boolean) => void;
  setJumping: (jumping: boolean) => void;
  setDead: (dead: boolean) => void;
  setInvincibility: (time: number) => void;
  updateInvincibility: (delta: number) => void;
  reset: () => void;
}

export const useMario = create<MarioState>()(
  subscribeWithSelector((set) => ({
    score: 0,
    lives: 3,
    coins: 0,
    position: [0, 2, 0],
    velocity: [0, 0, 0],
    isGrounded: false,
    isJumping: false,
    isDead: false,
    invincibilityTime: 0,
    
    addScore: (points: number) =>
      set((state) => ({ score: state.score + points })),
    
    addCoin: () =>
      set((state) => ({
        coins: state.coins + 1,
        score: state.score + 100,
      })),
    
    loseLife: () =>
      set((state) => {
        const newLives = state.lives - 1;
        return {
          lives: newLives,
          isDead: newLives <= 0,
          invincibilityTime: 2,
        };
      }),
    
    setPosition: (position) => set({ position }),
    setVelocity: (velocity) => set({ velocity }),
    setGrounded: (grounded) => set({ isGrounded: grounded }),
    setJumping: (jumping) => set({ isJumping: jumping }),
    setDead: (dead) => set({ isDead: dead }),
    setInvincibility: (time) => set({ invincibilityTime: time }),
    updateInvincibility: (delta) =>
      set((state) => ({
        invincibilityTime: Math.max(0, state.invincibilityTime - delta),
      })),
    
    reset: () =>
      set({
        score: 0,
        lives: 3,
        coins: 0,
        position: [0, 2, 0],
        velocity: [0, 0, 0],
        isGrounded: false,
        isJumping: false,
        isDead: false,
        invincibilityTime: 0,
      }),
  }))
);
