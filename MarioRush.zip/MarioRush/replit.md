# Overview

This is a 3D Mario-style platformer game built with React Three Fiber (R3F) and Express. The application features a browser-based 3D game where players control a character through a platforming environment, collecting coins, avoiding enemies, and managing lives. The frontend uses React with Three.js for 3D rendering, while the backend is a minimal Express server with a storage layer prepared for future database integration.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

**3D Game Engine**: Built on React Three Fiber (@react-three/fiber) with supporting libraries from @react-three/drei and @react-three/postprocessing for 3D rendering, camera controls, and visual effects.

**State Management**: Uses Zustand with subscribeWithSelector middleware for managing game state across three primary stores:
- `useGame`: Controls game phases (ready, playing, ended) and game flow
- `useMario`: Manages player state including position, velocity, physics properties, lives, score, and coins
- `useAudio`: Handles audio state and playback control for background music and sound effects

**Component Structure**: Game is divided into specialized 3D components:
- `Game`: Root canvas component that sets up the 3D scene, camera, and lighting
- `Mario`: Player character with physics-based movement and keyboard controls
- `Level`: Static platform and obstacle geometry
- `Enemies`: AI entities with patrol behaviors and collision detection
- `Coins`: Collectible items with rotation animations
- `GameUI`: 2D overlay displaying game state and controls

**Input Handling**: Keyboard controls managed through @react-three/drei's KeyboardControls provider, mapping arrow keys and WASD to movement actions.

**UI Framework**: Radix UI component library with Tailwind CSS for styling. Extensive UI component library included (accordion, alert, button, card, dialog, etc.) suggesting preparation for expanded UI features.

**Build System**: Vite for frontend bundling with React plugin, GLSL shader support, and custom path aliases. TypeScript configuration uses path mapping for `@/*` (client) and `@shared/*` (shared schema).

## Backend Architecture

**Server Framework**: Express.js with minimal routing configuration. Currently implements logging middleware for API requests but has placeholder route registration.

**Development Setup**: Vite integration in development mode with HMR support through HTTP server. Production build uses esbuild for server bundling.

**Storage Abstraction**: Implements a storage interface pattern with `IStorage` defining CRUD operations. Currently uses `MemStorage` (in-memory implementation) with prepared methods for user management. This abstraction allows easy swapping to database-backed storage.

**Session Management**: Dependencies include `connect-pg-simple` for PostgreSQL session storage, indicating planned session-based authentication.

## Data Layer

**ORM**: Drizzle ORM configured for PostgreSQL dialect with schema defined in `shared/schema.ts`.

**Database Provider**: Uses Neon serverless PostgreSQL (@neondatabase/serverless) as the database connection driver.

**Schema Design**: Currently defines a `users` table with fields for id (serial primary key), username (unique text), and password (text). Schema validation using Zod through drizzle-zod integration.

**Migrations**: Configured to output migration files to `./migrations` directory. Database URL required via environment variable `DATABASE_URL`.

**Type Safety**: Full TypeScript types generated from Drizzle schema, with `InsertUser` and `User` types exported for type-safe database operations.

## External Dependencies

**Database**: PostgreSQL database expected via `DATABASE_URL` environment variable. Uses Neon serverless driver for connection pooling and edge compatibility.

**3D Assets**: Configuration supports loading GLTF/GLB 3D model files and audio files (mp3, ogg, wav), though current implementation uses procedural geometry.

**Fonts**: Uses Inter font family via @fontsource/inter, with custom font JSON in public directory suggesting Three.js text rendering capabilities.

**Styling**: TailwindCSS with PostCSS for styling, custom CSS variables for theming (dark mode support configured).

**Development Tools**: Replit-specific vite plugin for runtime error overlay in development environment.